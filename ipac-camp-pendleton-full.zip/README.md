# IPAC Camp Pendleton Full Prototype

This version includes working frontend/backend code with in-memory DB and Docker setup.