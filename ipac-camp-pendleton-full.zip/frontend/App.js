// React App entry point
function App() { return <h1>IPAC Camp Pendleton</h1>; } export default App;