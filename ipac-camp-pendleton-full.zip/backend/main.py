# FastAPI backend entry point
from fastapi import FastAPI
app = FastAPI()