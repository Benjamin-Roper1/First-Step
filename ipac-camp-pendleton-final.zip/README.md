# IPAC Camp Pendleton Final Build

Includes styled frontend, FastAPI backend, CAC placeholder, Docker, and deployment notes.